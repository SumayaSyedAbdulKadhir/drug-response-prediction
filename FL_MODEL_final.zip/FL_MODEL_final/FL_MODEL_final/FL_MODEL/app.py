import numpy as np
import pandas as pd
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.model_selection import train_test_split
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader, TensorDataset

# Load the dataset
data = pd.read_csv('data_2.csv')

# Encode categorical variables (if any)
label_encoders = {}
for column in data.select_dtypes(include=['object']).columns:
    label_encoders[column] = LabelEncoder()
    data[column] = label_encoders[column].fit_transform(data[column])

# Split the data into features (X) and target (y)
X = data.drop('Drug_Response', axis=1).values
y = data['Drug_Response'].values

# Normalize the features
scaler = StandardScaler()
X = scaler.fit_transform(X)

# Reshape the data for LSTM input (samples, timesteps, features)
X = X.reshape(X.shape[0], 1, X.shape[1])

# Convert to PyTorch tensors
X_tensor = torch.tensor(X, dtype=torch.float32)
y_tensor = torch.tensor(y, dtype=torch.float32).view(-1, 1)

# Split the data into multiple clients for federated learning
def split_data_into_clients(X, y, num_clients):
    client_data = []
    client_labels = []
    data_per_client = len(X) // num_clients
    for i in range(num_clients):
        start = i * data_per_client
        end = start + data_per_client
        client_data.append(X[start:end])
        client_labels.append(y[start:end])
    return client_data, client_labels

num_clients = 5
client_data, client_labels = split_data_into_clients(X_tensor, y_tensor, num_clients)

# Define the LSTM model
class LSTMModel(nn.Module):
    def __init__(self, input_size, hidden_size, output_size):
        super(LSTMModel, self).__init__()
        self.lstm = nn.LSTM(input_size, hidden_size, batch_first=True)
        self.fc = nn.Linear(hidden_size, output_size)

    def forward(self, x):
        out, _ = self.lstm(x)
        out = self.fc(out[:, -1, :])
        return torch.sigmoid(out)

input_size = X.shape[2]
hidden_size = 50
output_size = 1

# Initialize the global model
global_model = LSTMModel(input_size, hidden_size, output_size)

# Federated Learning setup
def train_client_model(client_data, client_labels, model, epochs=10, batch_size=32):
    criterion = nn.BCELoss()
    optimizer = optim.Adam(model.parameters(), lr=0.001)
    dataset = TensorDataset(client_data, client_labels)
    dataloader = DataLoader(dataset, batch_size=batch_size, shuffle=True)

    model.train()
    for epoch in range(epochs):
        for inputs, labels in dataloader:
            optimizer.zero_grad()
            outputs = model(inputs)
            loss = criterion(outputs, labels)
            loss.backward()
            optimizer.step()
    return model.state_dict()

# Aggregate client models to form the global model
def aggregate_models(global_model, client_models):
    global_dict = global_model.state_dict()
    for key in global_dict.keys():
        global_dict[key] = torch.stack([client_models[i][key].float() for i in range(len(client_models))], 0).mean(0)
    global_model.load_state_dict(global_dict)
    return global_model

# Train the model using Federated Learning
num_rounds = 10
for round_num in range(num_rounds):
    client_models = []
    for i in range(num_clients):
        client_model = LSTMModel(input_size, hidden_size, output_size)
        client_model.load_state_dict(global_model.state_dict())
        client_model_state = train_client_model(client_data[i], client_labels[i], client_model)
        client_models.append(client_model_state)
    
    global_model = aggregate_models(global_model, client_models)
    print(f'Round {round_num + 1} completed.')

# Save the global model
torch.save(global_model.state_dict(), 'global_lstm_model.pth')
print("Global model saved successfully.")