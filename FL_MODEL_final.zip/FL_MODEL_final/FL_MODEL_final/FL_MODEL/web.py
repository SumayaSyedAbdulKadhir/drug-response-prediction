import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import streamlit as st
from sklearn.preprocessing import StandardScaler, LabelEncoder
import time

# Define the LSTM model class
class LSTMModel(nn.Module):
    def __init__(self, input_size, hidden_size, output_size):
        super(LSTMModel, self).__init__()
        self.lstm = nn.LSTM(input_size, hidden_size, batch_first=True)
        self.fc = nn.Linear(hidden_size, output_size)

    def forward(self, x):
        out, _ = self.lstm(x)
        out = self.fc(out[:, -1, :])
        return torch.sigmoid(out)

# Load the saved global model
input_size = 14  # Number of features
hidden_size = 50
output_size = 1

global_model = LSTMModel(input_size, hidden_size, output_size)
global_model.load_state_dict(torch.load('global_lstm_model.pth'))
global_model.eval()  # Set the model to evaluation mode

# Function to preprocess new input data
def preprocess_input(new_data, label_encoders, scaler):
    # Encode categorical variables (if any)
    for column in new_data.select_dtypes(include=['object']).columns:
        new_data[column] = label_encoders[column].transform(new_data[column])

    # Normalize the features
    new_data = scaler.transform(new_data)

    # Reshape the data for LSTM input (samples, timesteps, features)
    new_data = new_data.reshape(new_data.shape[0], 1, new_data.shape[1])

    # Convert to PyTorch tensor
    new_data_tensor = torch.tensor(new_data, dtype=torch.float32)

    return new_data_tensor

# Load the original dataset to fit the scaler
data = pd.read_csv('data_2.csv')

# Encode categorical variables (if any)
label_encoders = {}
for column in data.select_dtypes(include=['object']).columns:
    label_encoders[column] = LabelEncoder()
    data[column] = label_encoders[column].fit_transform(data[column])

# Fit the scaler on the original dataset
scaler = StandardScaler()
scaler.fit(data.drop('Drug_Response', axis=1).values)

# Streamlit app layout
st.set_page_config(page_title="Drug Response Prediction", page_icon="🔬", layout="centered")
st.title('Drug Response Prediction using LSTM')

# Sidebar with input forms
st.sidebar.header("Input Data for Prediction")
st.sidebar.subheader("Genetic Data (SNP Values)")
snp_values = [st.sidebar.number_input(f"SNP_{i+1}", min_value=0.0, max_value=1.0, step=0.01, format="%.2f") for i in range(10)]

st.sidebar.subheader("Demographic Information")
age = st.sidebar.number_input("Age", min_value=0, max_value=100, help="Enter the age of the individual.")
sex = st.sidebar.selectbox("Sex", ["Female", "Male"], help="Select the sex of the individual.")
ethnicity = st.sidebar.selectbox("Ethnicity", ["East Asian", "South Asian", "African", "American", "European"], help="Select the ethnicity of the individual.")
drug_name = st.sidebar.text_input("Drug Name", help="Enter the name of the drug.")

# Create a DataFrame from user inputs
new_data = pd.DataFrame({
    'SNP_1': [snp_values[0]],
    'SNP_2': [snp_values[1]],
    'SNP_3': [snp_values[2]],
    'SNP_4': [snp_values[3]],
    'SNP_5': [snp_values[4]],
    'SNP_6': [snp_values[5]],
    'SNP_7': [snp_values[6]],
    'SNP_8': [snp_values[7]],
    'SNP_9': [snp_values[8]],
    'SNP_10': [snp_values[9]],
    'Age': [age],
    'Sex': [sex],
    'Ethnicity': [ethnicity],
    'Drug_Name': [drug_name]
})

# Show input data
st.write("### Input Data", new_data)

# Button to trigger prediction
if st.button("Predict Drug Response"):

    # Display loading spinner while processing
    with st.spinner('Processing your data...'):
        time.sleep(2)  # Simulate processing time
        
        try:
            # Preprocess the input data
            new_data_tensor = preprocess_input(new_data, label_encoders, scaler)

            # Make predictions
            with torch.no_grad():
                predictions = global_model(new_data_tensor)

            # Convert predictions to numpy array
            predictions = predictions.numpy()

            # Apply threshold to get binary predictions (1 or 0)
            threshold = 0.5
            binary_predictions = (predictions >= threshold).astype(int)

            # Show results with some explanation
            if binary_predictions == 1:
                st.success("Prediction: The drug response is 0. The person is responsive to the drug.")
            else:
                st.error("Prediction: The drug response is (1). The person is not responsive to the drug.")

        except Exception as e:
            st.error(f"An error occurred: {e}")

# Show additional information and download link (if applicable)
st.markdown("""
    ### About this Model
    This model predicts the drug response based on various factors including genetic SNPs, age, sex, and ethnicity. 
    It uses a pre-trained LSTM model to predict the likelihood of a positive or negative response to the specified drug.
    
    **Model Details**:
    - **Input Features**: SNP values, Age, Sex, Ethnicity, Drug Name.
    - **Output**: Binary response (Positive or Negative).

    **Instructions**:
    1. Input the required information in the sidebar.
    2. Click on the "Predict Drug Response" button.
    3. View the result of the prediction based on the entered data.

""")
