import numpy as np
import pandas as pd
from sklearn.preprocessing import StandardScaler, LabelEncoder
import torch
import torch.nn as nn

# Define the LSTM model class
class LSTMModel(nn.Module):
    def __init__(self, input_size, hidden_size, output_size):
        super(LSTMModel, self).__init__()
        self.lstm = nn.LSTM(input_size, hidden_size, batch_first=True)
        self.fc = nn.Linear(hidden_size, output_size)

    def forward(self, x):
        out, _ = self.lstm(x)
        out = self.fc(out[:, -1, :])
        return torch.sigmoid(out)

# Load the saved global model
input_size = 14  # Number of features
hidden_size = 50
output_size = 1

global_model = LSTMModel(input_size, hidden_size, output_size)
global_model.load_state_dict(torch.load('global_lstm_model.pth'))
global_model.eval()  # Set the model to evaluation mode

# Function to preprocess new input data
def preprocess_input(new_data, label_encoders, scaler):
    # Encode categorical variables (if any)
    for column in new_data.select_dtypes(include=['object']).columns:
        new_data[column] = label_encoders[column].transform(new_data[column])

    # Normalize the features
    new_data = scaler.transform(new_data)

    # Reshape the data for LSTM input (samples, timesteps, features)
    new_data = new_data.reshape(new_data.shape[0], 1, new_data.shape[1])

    # Convert to PyTorch tensor
    new_data_tensor = torch.tensor(new_data, dtype=torch.float32)

    return new_data_tensor

# Example new input data
new_data = pd.DataFrame({
    'SNP_1': [0.7122741612744207],
    'SNP_2': [0.9968829769333583],
    'SNP_3': [0.09644910222910053],
    'SNP_4': [0.27153279320684964],
    'SNP_5': [0.6459336634169652],
    'SNP_6': [0.36923980452941074],
    'SNP_7': [0.683278136624016],
    'SNP_8': [0.9373568067805869],
    'SNP_9': [0.14505886974294202],
    'SNP_10': [0.2204151653437606],
    'Age': [21],
    'Sex': ['Female'],
    'Ethnicity': ['East Asian'],
    'Drug_Name': ['Varenicline']
})

# Load the original dataset to fit the scaler
data = pd.read_csv('data_2.csv')

# Encode categorical variables (if any)
label_encoders = {}
for column in data.select_dtypes(include=['object']).columns:
    label_encoders[column] = LabelEncoder()
    data[column] = label_encoders[column].fit_transform(data[column])

# Fit the scaler on the original dataset
scaler = StandardScaler()
scaler.fit(data.drop('Drug_Response', axis=1).values)

# Preprocess the new input data
new_data_tensor = preprocess_input(new_data, label_encoders, scaler)

# Make predictions
with torch.no_grad():
    predictions = global_model(new_data_tensor)

# Convert predictions to numpy array
predictions = predictions.numpy()

# Apply threshold to get binary predictions (1 or 0)
threshold = 0.5
binary_predictions = (predictions >= threshold).astype(int)

print("Binary Predictions:", binary_predictions)