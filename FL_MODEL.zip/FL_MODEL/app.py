import torch
import torch.nn as nn
import torch.optim as optim
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, LabelEncoder
from torch.utils.data import DataLoader, Dataset
import numpy as np
import copy

# Load data
df = pd.read_csv("data_2.csv")

# Encode categorical columns (Sex, Ethnicity, Drug_Name)
label_encoders = {
    'Sex': LabelEncoder(),
    'Ethnicity': LabelEncoder(),
    'Drug_Name': LabelEncoder()
}

df['Sex'] = label_encoders['Sex'].fit_transform(df['Sex'])
df['Ethnicity'] = label_encoders['Ethnicity'].fit_transform(df['Ethnicity'])
df['Drug_Name'] = label_encoders['Drug_Name'].fit_transform(df['Drug_Name'])

# Separate features and target
X = df.drop(columns=['Drug_Response'])
y = df['Drug_Response']

# Normalize the features
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# Convert to PyTorch tensors
X_tensor = torch.tensor(X_scaled, dtype=torch.float32)
y_tensor = torch.tensor(y.values, dtype=torch.long)

# Split the data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X_scaled, y, test_size=0.2, random_state=42)

# Convert test data to PyTorch tensors
X_test_tensor = torch.tensor(X_test, dtype=torch.float32)
y_test_tensor = torch.tensor(y_test.values, dtype=torch.long)

# Define the dataset class
class DrugResponseDataset(Dataset):
    def __init__(self, features, labels):
        self.features = features
        self.labels = labels

    def __len__(self):
        return len(self.features)

    def __getitem__(self, idx):
        return self.features[idx], self.labels[idx]

# Define test dataset and DataLoader
test_dataset = DrugResponseDataset(X_test_tensor, y_test_tensor)
test_loader = DataLoader(test_dataset, batch_size=32, shuffle=False)

# Split the data into multiple clients (simulating federated learning)
num_clients = 5  # You can adjust the number of clients
client_data = np.array_split(X_tensor, num_clients)
client_labels = np.array_split(y_tensor, num_clients)

# Create DataLoader for each client
client_loaders = []
for i in range(num_clients):
    client_dataset = DrugResponseDataset(client_data[i], client_labels[i])
    client_loader = DataLoader(client_dataset, batch_size=32, shuffle=True)
    client_loaders.append(client_loader)

# Define the neural network model
class SimpleNN(nn.Module):
    def __init__(self, input_dim):
        super(SimpleNN, self).__init__()
        self.fc1 = nn.Linear(input_dim, 128)
        self.fc2 = nn.Linear(128, 64)
        self.fc3 = nn.Linear(64, 2)  # Output 2 classes (0 or 1 for Drug_Response)

    def forward(self, x):
        x = torch.relu(self.fc1(x))
        x = torch.relu(self.fc2(x))
        x = self.fc3(x)
        return torch.softmax(x, dim=1)

# Instantiate the global model
input_dim = X_tensor.shape[1]
global_model = SimpleNN(input_dim)
criterion = nn.CrossEntropyLoss()  # For classification
optimizer = optim.Adam(global_model.parameters(), lr=0.00001)

# Federated Learning Training Loop
num_epochs = 100
for epoch in range(num_epochs):
    print(f"Epoch {epoch+1}/{num_epochs}")
    
    # Step 1: Local training on each client
    local_models = []
    for client_loader in client_loaders:
        local_model = copy.deepcopy(global_model)  # Create a copy of the global model for the client
        local_optimizer = optim.Adam(local_model.parameters(), lr=0.001)
        
        local_model.train()
        for data, target in client_loader:
            local_optimizer.zero_grad()
            output = local_model(data)
            loss = criterion(output, target)
            loss.backward()
            local_optimizer.step()
        
        local_models.append(local_model.state_dict())  # Save the model's state dict (weights)

    # Step 2: Aggregate the model updates
    global_state_dict = global_model.state_dict()
    
    # Average the weights of the local models to create a new global model
    for key in global_state_dict:
        global_state_dict[key] = torch.mean(torch.stack([torch.tensor(local_model[key]) for local_model in local_models]), dim=0)
    
    # Update the global model with the averaged weights
    global_model.load_state_dict(global_state_dict)
    
    print(f"Epoch {epoch+1} complete!")

# Save the global model
torch.save(global_model.state_dict(), 'federated_drug_response_model.pth')
print("Federated model saved as 'federated_drug_response_model.pth'")

# Function to load the model
def load_model(model_path, input_dim):
    model = SimpleNN(input_dim)
    model.load_state_dict(torch.load(model_path))
    model.eval()  # Set model to evaluation mode
    return model

# Function to make predictions
def predict(model, input_data):
    input_tensor = torch.tensor(input_data, dtype=torch.float32).unsqueeze(0)  # Add batch dimension
    with torch.no_grad():
        output = model(input_tensor)
        _, predicted = torch.max(output, 1)
        return predicted.item()

# Function to calculate accuracy
def evaluate_accuracy(model, dataloader):
    model.eval()  # Set model to evaluation mode
    correct = 0
    total = 0
    with torch.no_grad():
        for data, target in dataloader:
            output = model(data)
            _, predicted = torch.max(output, 1)
            total += target.size(0)
            correct += (predicted == target).sum().item()
    accuracy = 100 * correct / total
    return accuracy

# Evaluate accuracy after training
test_accuracy = evaluate_accuracy(global_model, test_loader)
print(f"Test Accuracy: {test_accuracy:.2f}%")

# Example: Load the trained model and make a prediction
model_path = 'federated_drug_response_model.pth'
input_dim = X_tensor.shape[1]  # Should match the number of features used during training

# Load the model
model = load_model(model_path, input_dim)

# Example: Predict the response for a new sample
new_sample = X_tensor[0].numpy()  # Take the first sample from the dataset
predicted_response = predict(model, new_sample)

print(f"Predicted drug response for the new sample: {predicted_response}")
