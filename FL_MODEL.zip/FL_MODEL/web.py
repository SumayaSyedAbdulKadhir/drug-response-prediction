import streamlit as st
import torch
import torch.nn as nn
import pandas as pd
from sklearn.preprocessing import StandardScaler, LabelEncoder

# Define the model structure (same as during training)
class SimpleNN(nn.Module):
    def __init__(self, input_dim):
        super(SimpleNN, self).__init__()
        self.fc1 = nn.Linear(input_dim, 128)
        self.fc2 = nn.Linear(128, 64)
        self.fc3 = nn.Linear(64, 2)  # Output 2 classes (0 or 1 for Drug_Response)

    def forward(self, x):
        x = torch.relu(self.fc1(x))
        x = torch.relu(self.fc2(x))
        x = self.fc3(x)
        return torch.softmax(x, dim=1)

# Function to load the trained model
@st.cache_resource
def load_model(model_path, input_dim):
    model = SimpleNN(input_dim)
    model.load_state_dict(torch.load(model_path, map_location=torch.device('cpu')))
    model.eval()  # Set model to evaluation mode
    return model

# Load the model
model_path = 'federated_drug_response_model.pth'  # Ensure this file exists
input_dim = 14  # Number of features (SNP_1 to SNP_10, Age, Sex, Ethnicity)
model = load_model(model_path, input_dim)

# Function to preprocess the input data
def preprocess_input(input_data):
    label_encoders = {
        'Sex': LabelEncoder(),
        'Ethnicity': LabelEncoder(),
        'Drug_Name': LabelEncoder()
    }
    input_data['Sex'] = label_encoders['Sex'].fit_transform(input_data['Sex'])
    input_data['Ethnicity'] = label_encoders['Ethnicity'].fit_transform(input_data['Ethnicity'])
    input_data['Drug_Name'] = label_encoders['Drug_Name'].fit_transform(input_data['Drug_Name'])
    
    scaler = StandardScaler()
    input_scaled = scaler.fit_transform(input_data)
    input_tensor = torch.tensor(input_scaled, dtype=torch.float32)
    return input_tensor

# Define a mapping for categorical labels
class_mapping = {0: 'Responder', 1: 'Non-Responder'}

# Function to make predictions and return categorical labels
def predict(model, input_data):
    input_tensor = preprocess_input(input_data)
    with torch.no_grad():
        output = model(input_tensor)
        _, predicted = torch.max(output, 1)
        predicted_label = class_mapping[predicted.item()]
        return predicted_label

# Streamlit App
st.title("Drug Response Prediction")

# User input form
st.header("Enter Patient Data")

# Create a form for manual input
with st.form("patient_data_form"):
    SNPs = {f"SNP_{i}": st.number_input(f"SNP_{i} (0.0 to 1.0)", min_value=0.0, max_value=1.0, value=0.5) for i in range(1, 11)}
    age = st.number_input("Age", min_value=0, max_value=100, value=45)
    sex = st.selectbox("Sex", ["Male", "Female"])
    ethnicity = st.selectbox("Ethnicity", ["African", "South Asian", "East Asian", "American", "European"])
    drug_name = st.text_input("Drug Name", "Hydrochlorothiazide")
    
    # Submit button inside the form
    submit = st.form_submit_button("Predict Response")

if submit:
    # Prepare the input DataFrame
    input_data = pd.DataFrame([{**SNPs, 'Age': age, 'Sex': sex, 'Ethnicity': ethnicity, 'Drug_Name': drug_name}])

    # Display user input
    st.subheader("Input Data")
    st.write(input_data)

    # Prediction
    try:
        prediction = predict(model, input_data)
        st.success(f"Predicted Drug Response: {prediction}")
    except Exception as e:
        st.error(f"An error occurred: {e}")
