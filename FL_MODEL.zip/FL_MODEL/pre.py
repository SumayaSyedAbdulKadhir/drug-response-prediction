import streamlit as st
import torch
import torch.nn as nn
import pandas as pd
from sklearn.preprocessing import StandardScaler, LabelEncoder

# Define the model structure (same as during training)
class SimpleNN(nn.Module):
    def __init__(self, input_dim):
        super(SimpleNN, self).__init__()
        self.fc1 = nn.Linear(input_dim, 128)
        self.fc2 = nn.Linear(128, 64)
        self.fc3 = nn.Linear(64, 2)  # Output 2 classes (0 or 1 for Drug_Response)

    def forward(self, x):
        x = torch.relu(self.fc1(x))
        x = torch.relu(self.fc2(x))
        x = self.fc3(x)
        return torch.softmax(x, dim=1)

# Load the trained model
@st.cache_resource
def load_model(model_path, input_dim):
    model = SimpleNN(input_dim)
    model.load_state_dict(torch.load(model_path, map_location=torch.device('cpu')))
    model.eval()  # Set model to evaluation mode
    return model

# Preprocess the raw input data
def preprocess_input(input_data):
    # Encode categorical features
    label_encoders = {
        'Sex': LabelEncoder(),
        'Ethnicity': LabelEncoder(),
        'Drug_Name': LabelEncoder()
    }
    
    input_data['Sex'] = label_encoders['Sex'].fit_transform(input_data['Sex'])
    input_data['Ethnicity'] = label_encoders['Ethnicity'].fit_transform(input_data['Ethnicity'])
    input_data['Drug_Name'] = label_encoders['Drug_Name'].fit_transform(input_data['Drug_Name'])
    
    # Normalize the features
    scaler = StandardScaler()
    input_scaled = scaler.fit_transform(input_data)
    
    # Convert the input to PyTorch tensor
    input_tensor = torch.tensor(input_scaled, dtype=torch.float32)
    return input_tensor

# Function to make predictions and return categorical labels
def predict(model, input_data):
    input_tensor = preprocess_input(input_data)
    with torch.no_grad():
        output = model(input_tensor)
        _, predicted = torch.max(output, 1)
        # Map numerical prediction to categorical label
        class_mapping = {0: 'Non-Responder', 1: 'Responder'}
        predicted_label = class_mapping[predicted.item()]
        return predicted_label

# Load the model
model_path = 'federated_drug_response_model.pth'
input_dim = 14  # Number of features
model = load_model(model_path, input_dim)

# Streamlit App
st.title("Drug Response Prediction")

st.sidebar.header("Input Features")

# Input fields
SNP_features = {f'SNP_{i}': st.sidebar.number_input(f'SNP_{i}', min_value=0.0, max_value=1.0, value=0.5) for i in range(1, 11)}
Age = st.sidebar.number_input("Age", min_value=0, max_value=120, value=45)
Sex = st.sidebar.selectbox("Sex", ["Male", "Female"])
Ethnicity = st.sidebar.selectbox("Ethnicity", ["African", "South Asian", "East Asian", "European", "American"])
Drug_Name = st.sidebar.text_input("Drug Name", "Hydrochlorothiazide")

# Combine input into a DataFrame
input_data = pd.DataFrame([{
    **SNP_features,
    'Age': Age,
    'Sex': Sex,
    'Ethnicity': Ethnicity,
    'Drug_Name': Drug_Name
}])

st.subheader("Input Data")
st.write(input_data)

# Predict button
if st.button("Predict Drug Response"):
    predicted_response = predict(model, input_data)
    st.subheader("Prediction")
    st.write(f"Predicted Drug Response: **{predicted_response}**")
